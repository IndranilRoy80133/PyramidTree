
from typing import Any, Generic, Type, TypeVar
from singleton import singleton


TK = TypeVar('TK')
TV = TypeVar('TV')

class AddressTable(Generic[TK, TV]):

    def __init__(self) -> None:
        super().__init__()
        self._table: dict[TK, TV] = {}

    def set(self, address: TK, value: TV):
        if value == None and address in self._table:
            self._table.pop(address)
        else:
            self._table[address] = value

    def get(self, address: TK) -> TV:
        return self._table.get(address, None)

    def len(self) -> int:
        return len(self._table.keys())

    def clone(self):
        clone = AddressTable[TK, TV]()
        clone._table = self._table.copy()
        return clone

class AddressToIpTable(AddressTable[int, str]):

    def __init__(self) -> None:
        super().__init__()

    def set(self, node):
        super().set(node._address, node._ip)

class IpToNodeTable(AddressTable[str, Any]):

    def set(self, node):
        super().set(node._ip, node)

@singleton
class GlobalIpToNodeTable(IpToNodeTable):
    
    def __init__(self) -> None:
        super().__init__()
