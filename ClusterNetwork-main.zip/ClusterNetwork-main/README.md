# About

This project is a simulation of clusters of nodes within a network that use a Pyramid tree structure to broadcast information throughout the network.

The simulation events are based on the article linked here:<br>
https://www.grotto-networking.com/DiscreteEventPython.html

# Creating the Virtual Environment

**Further Reading:** https://docs.python.org/3/library/venv.html

- Navigate to the project root create a new folder `venv` and then type 
    ```console
    python3 -m venv ./venv
    ```

- Next modify your `activate.bat` or `activate` file located in `{project_root}/venv/Scripts/` depending on if your're in a Windows or Linux environment<br>
**Why?** This is done so we can import from the project root without using relative imports<br><br>

    - **Windows** - modify the `activate.bat` file by adding the following lines to the end of the file
        ```bat
        set PROJECT_ROOT=C:\Path\To\Project\Root
        set PYTHONPATH=%PROJECT_ROOT%;%PYTHONPATH%
        ```

    - **Linux** - modfy the `activate` file by adding the following line to the end of the file<br>
    **Note:** If modifing this file on windows for git bash you should use a semicolon rather than a colon
        ```sh
        PYTHONPATH="${PYTHONPATH}:/Path/To/Project/Root"
        export PYTHONPATH
        ```

# Activiating the virtual environment

- Using VS code this can be done sutomatically by adding these lines to your `settings.json` file<br>
**Note:** you will have to open a new console window for these changes to take effect<br>
**Further Reading:** https://code.visualstudio.com/docs/python/settings-reference
    ```json
    "python.terminal.activateEnvironment": true,
    "python.defaultInterpreterPath": "${workspaceFolder}/venv/Scripts/python"
    ```

- You can also manually activate the virtual environment by typing
    - For Windows
        ```bat
        .\venv\Scripts\activate.bat
        ```
    - For Linux
        ```sh
        ./venv/Scripts/activate
        ```

# Packages

## Installing

**Ensure you have the virtual environment active**

From project root type the following
```console
pip install -r ./requirements/requirements.txt 
```

## Adding new packages

**Further Reading:** https://pypi.org/project/pip-tools/

**Ensure you have the virtual environment active**

Add the packages to the `./requirements/requirements.in` file then, cd into the requirements folder then run
```console
pip-compile requirements.in
```
