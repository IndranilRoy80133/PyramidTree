
from math import sqrt
from math import ceil
import random
from singleton import singleton

# derived from (solving for n) based on triangular number sequence
# x = (n * (n + 1)) / 2
def calc_height_of_tree(num_nodes: int) -> int:
    return ceil((sqrt(8 * num_nodes + 1) - 1) / 2)

def calc_how_many_nodes_in_full_tree(height: int) -> int:
    return int((height * (height + 1)) / 2)

@singleton
class IPGenerator():
    _used = set[str]()

    def generate_ip(self):
        return '{}.{}.{}.{}'.format(*random.sample(range(0,255),4))

    def generate_unique_ip(self):
        ip = self.generate_ip()
        while(ip in self._used):
            ip = self.generate_ip()
        self._used.add(ip)
        return ip
