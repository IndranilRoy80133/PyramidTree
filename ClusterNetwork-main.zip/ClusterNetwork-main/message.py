
from enum import Enum

class Action(Enum):
    CHANGE_CLUSTER_HEAD = 1
    DELETE_CLUSTER_HEAD = 2
    STRING_MESSAGE = 3

class Message():
    action: Action

    def __init__(self, action: Action) -> None:
        self.action = action

    def __str__(self) -> str:
        return self.action.name

class StringMessage(Message):

    def __init__(self, message) -> None:
        super().__init__(Action.STRING_MESSAGE)
        self._message: str = message

    @property
    def message(self) -> str:
        return self._message

    @message.setter
    def message(self, value: str):
        self._message = value
    
class ChangeClusterHead(Message):

    def __init__(self, new_cluster_head) -> None:
        super().__init__(Action.CHANGE_CLUSTER_HEAD)
        self._address: int = new_cluster_head._address
        self._ip: str = new_cluster_head._ip

    def __init__(self, address: int, ip: str) -> None:
        super().__init__(Action.CHANGE_CLUSTER_HEAD)
        self._address: int = address
        self._ip: str = ip

    @property
    def address(self) -> int:
        return self._address
    
    @address.setter
    def address(self, value: int):
        self._address = value

    @property
    def ip(self) -> str:
        return self._ip

    @ip.setter
    def ip(self, value: str):
        self._ip = value


class DeleteClusterHead(Message):

    def __init__(self, address: int) -> None:
        super().__init__(Action.DELETE_CLUSTER_HEAD)
        self._address: int = address

    @property
    def address(self) -> int:
        return self._address
    
    @address.setter
    def address(self, value: int):
        self._address = value
