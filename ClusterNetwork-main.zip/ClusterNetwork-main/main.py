
from address_table import AddressToIpTable, GlobalIpToNodeTable
from cluster_head import ClusterHead
from message import DeleteClusterHead, StringMessage


N_CLUSTERS = 13

# init the clusters
cluster_heads: list[ClusterHead] = []
for i in range(N_CLUSTERS):
    cluster_heads.append(ClusterHead(i, N_CLUSTERS))

# add the clusters to the global ip lookup table
global_ip_table = GlobalIpToNodeTable()
for ch in cluster_heads: global_ip_table.set(ch) 

# build the inital address tables for the clusters
address_table = AddressToIpTable()
for ch in cluster_heads: address_table.set(ch)
for ch in cluster_heads: ch.address_table = address_table.clone()

broad_cast_num = 4
delete_num = 6
cluster_heads[broad_cast_num].broadcast(StringMessage(f'cluster head {broad_cast_num} sent this'))
cluster_heads[delete_num].broadcast(DeleteClusterHead(cluster_heads[delete_num]._address))
print()
cluster_heads[broad_cast_num].broadcast(StringMessage(f'cluster head {broad_cast_num} sent this'))
