
from typing import Type
from address_table import AddressToIpTable, GlobalIpToNodeTable
from message import Action, ChangeClusterHead, DeleteClusterHead, Message, StringMessage
from utils import IPGenerator, calc_height_of_tree, calc_how_many_nodes_in_full_tree


class ClusterHead():

    def __init__(self, address: int, n_clusters: int, _ip = None) -> None:
        self._address_table: AddressToIpTable = AddressToIpTable()
        self._n_clusters: int = n_clusters
        self._my_messages: list[Message] = []
        self._residue_class: int = address % n_clusters
        self._address: int = address
        self._ip: str = _ip if _ip else IPGenerator().generate_unique_ip()
        self._address_table_changed()

    def broadcast(self, message: Type[Message]) -> None:
        self._receive(message, 1, 0)
    
    def _broadcast(self, message: Type[Message], level: int, distance_from_center: int) -> None:
        if level >= self._height_of_the_tree:
            return

        count_from_right = (level - distance_from_center + 1) / 2

        # this prevents us from interacting with nodes at the bottom of the tree
        # that do not exist
        left_node_exists = True
        right_node_exists = True
        # if there are missing nodes and we are at one level above the bottom of the tree
        if self._missing_nodes_in_tree > 0 and level == self._height_of_the_tree - 1:
            left_node_exists = count_from_right >= self._missing_nodes_in_tree
            right_node_exists = count_from_right > self._missing_nodes_in_tree

        # left path
        # if the next node exists
        if left_node_exists:
            left_address = (self._residue_class + level) % self._num_active_clusters
            left_node_ip = self._address_table.get(left_address)
            left_node: ClusterHead = GlobalIpToNodeTable().get(left_node_ip)
            if left_node: left_node._receive(message, level + 1, distance_from_center - 1)

        # right path
        # if this is the right most path and the next node exists
        if count_from_right == 1 and right_node_exists:
            right_address = (self._residue_class + level + 1) % self._num_active_clusters
            right_node_ip = self._address_table.get(right_address)
            right_node: ClusterHead = GlobalIpToNodeTable().get(right_node_ip)
            if right_node: right_node._receive(message, level + 1, distance_from_center + 1)

    def _receive(self, message: Type[Message], level: int, distance_from_center: int) -> None:
        self._my_messages.append(message)
        self._broadcast(message, level, distance_from_center)
        if message.action == Action.CHANGE_CLUSTER_HEAD:
            self._handle_change_cluster_head(message)
        elif message.action == Action.STRING_MESSAGE:
            self._handle_string_message(message)
        elif message.action == Action.DELETE_CLUSTER_HEAD:
            self._handle_delete_cluster_head(message)

    def _handle_change_cluster_head(self, message: ChangeClusterHead) -> None:
        if message:
            if message.ip:
                self._address_table.set(message.address % self._n_clusters, message.ip)
                self._address_table_changed()
            else:
                self._handle_delete_cluster_head(DeleteClusterHead(message.address))

    def _handle_delete_cluster_head(self, message: DeleteClusterHead) -> None:
        if message:
            modded_value = message.address % self._n_clusters
            # shift values
            while modded_value < self._n_clusters:
                self._address_table.set(modded_value, self._address_table.get(modded_value + 1))
                modded_value += 1
            # ensure final is empty
            self._address_table.set(self._n_clusters - 1, None)
            self._address_table_changed()

    def _handle_string_message(self, message: StringMessage) -> None:
        if message:
            print(f'cluster head {self._address} received message "{message.message}"')

    # updates all variables related to the address table
    def _address_table_changed(self):
        self._num_active_clusters: int = self._address_table.len()
        self._height_of_the_tree: int = calc_height_of_tree(self._num_active_clusters)
        self._missing_nodes_in_tree: int = calc_how_many_nodes_in_full_tree(self._height_of_the_tree) - self._num_active_clusters

    @property
    def address_table(self) -> AddressToIpTable:
        return self._address_table

    @address_table.setter
    def address_table(self, value: AddressToIpTable):
        self._address_table = value
        self._address_table_changed()
